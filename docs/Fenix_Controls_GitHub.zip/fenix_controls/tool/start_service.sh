#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -z "${FENIX_DATA_DIR:-}" ]] && [[ "$(uname -r)" == *[Mm]icrosoft* ]]; then
  windows_local_appdata="$(/mnt/c/Windows/System32/cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')"
  export FENIX_DATA_DIR="$(wslpath -u "$windows_local_appdata")/FenixControls"
fi
exec python3 "$script_dir/fenix_api.py" "$@"
