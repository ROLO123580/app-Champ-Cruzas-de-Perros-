$ErrorActionPreference = 'Stop'
# Ejecuta siempre el servicio en WSL, compartido por Chrome y Windows.
$scriptPath = Join-Path $PSScriptRoot 'start_service.sh'
$unixPath = & wsl.exe wslpath -u $scriptPath
if ($LASTEXITCODE -ne 0) { throw 'No se pudo resolver la ruta en WSL.' }
& wsl.exe bash $unixPath.Trim()
exit $LASTEXITCODE
