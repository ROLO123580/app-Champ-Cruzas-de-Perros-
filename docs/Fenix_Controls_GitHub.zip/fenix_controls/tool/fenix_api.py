"""Servicio SQLite local. Python 3.9+, sin dependencias externas."""
import argparse
import json
import os
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit
import sys


def default_directory():
    if os.environ.get('FENIX_DATA_DIR'):
        return Path(os.environ['FENIX_DATA_DIR'])
    if sys.platform == 'win32':
        return Path(os.environ['LOCALAPPDATA']) / 'FenixControls'
    if 'microsoft' in os.uname().release.lower():
        raise ValueError('En WSL define FENIX_DATA_DIR con una carpeta persistente de Windows, por ejemplo /mnt/c/Users/TU_USUARIO/AppData/Local/FenixControls')
    return Path.home() / '.local' / 'share' / 'FenixControls'


class Store:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = open(self.directory / 'service.lock', 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.lock.seek(0)
                self.lock.write(b'0')
                self.lock.flush()
                self.lock.seek(0)
                msvcrt.locking(self.lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.lock.close()
            raise ValueError('La base está en uso: detén el otro servicio antes de abrir o restaurar')
        self.path = self.directory / 'fenix_controls.db' 
        self.db = sqlite3.connect(self.path)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('PRAGMA synchronous=FULL')
        version = self.db.execute('PRAGMA user_version').fetchone()[0]
        if version > 1:
            raise ValueError('La base requiere una versión más reciente del servicio')
        with self.db:
            self.db.execute('CREATE TABLE IF NOT EXISTS apps (id TEXT PRIMARY KEY, data TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS logs (id TEXT PRIMARY KEY, app_id TEXT NOT NULL REFERENCES apps(id) ON DELETE CASCADE, data TEXT NOT NULL)')
            self.db.execute('PRAGMA user_version=1')
        if self.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('La base no supera la comprobación de integridad; no se modificará')
        self.backup()

    def state(self):
        return {table: [json.loads(row[0]) for row in self.db.execute(f'SELECT data FROM {table} ORDER BY id')] for table in ('apps', 'logs')}

    def backup(self):
        folder = self.directory / 'respaldos'
        folder.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        target = folder / f'fenix-{stamp}.db'
        try:
            with sqlite3.connect(target) as dest:
                self.db.backup(dest)
                if dest.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                    raise ValueError('No se pudo verificar el respaldo')
        except Exception:
            target.unlink(missing_ok=True)
            raise
        return str(target)

    def mutate(self, method, path, data):
        if method == 'POST' and path == '/backup':
            return {'path': self.backup()}
        if method == 'POST' and path in ('/apps', '/logs'):
            self.validate(data, path == '/logs')
            self.backup()  # Si falla la copia, no se modifica la base.
            with self.db:
                encoded = json.dumps(data, ensure_ascii=False)
                if path == '/apps':
                    self.db.execute('INSERT INTO apps(id,data) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data', (data['id'], encoded))
                else:
                    self.db.execute('INSERT INTO logs(id,app_id,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET app_id=excluded.app_id,data=excluded.data', (data['id'], data['appId'], encoded))
            return {'ok': True}
        if method == 'DELETE' and path == '/apps':
            if not isinstance(data, dict) or not isinstance(data.get('id'), str) or not data['id']:
                raise ValueError('ID inválido')
            self.backup()
            with self.db:
                self.db.execute('DELETE FROM apps WHERE id=?', (data['id'],))
            return {'ok': True}
        raise ValueError('Operación desconocida')

    @staticmethod
    def validate(data, log):
        if not isinstance(data, dict):
            raise ValueError('Se esperaba un objeto JSON')
        strings = ('id', 'appId', 'appName', 'note', 'createdAt') if log else ('id', 'name', 'type', 'status', 'nextAction', 'createdAt', 'updatedAt')
        if any(not isinstance(data.get(key), str) for key in strings) or not data['id']:
            raise ValueError('Campos de texto inválidos')
        for key in (('createdAt',) if log else ('createdAt', 'updatedAt')):
            datetime.fromisoformat(data[key].replace('Z', '+00:00'))
        if not log and data.get('targetDate') is not None:
            datetime.fromisoformat(data['targetDate'].replace('Z', '+00:00'))
        for key, low, high in ([('minutes', 1, 10000000)] if log else [('progress', 0, 100), ('priority', 1, 5)]):
            value = data.get(key)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f'{key} inválido')

    def close(self):
        self.db.close()
        self.lock.close()


class Handler(BaseHTTPRequestHandler):
    def handle_request(self):
        origin = self.headers.get('Origin')
        host = urlsplit('http://' + self.headers.get('Host', '')).hostname
        local_hosts = ('localhost', '127.0.0.1', '::1')
        if host not in local_hosts:
            self.reply(403, {'error': 'Host no autorizado'})
            return
        if origin and (urlsplit(origin).hostname not in local_hosts or urlsplit(origin).scheme != 'http'):
            self.reply(403, {'error': 'Origen no autorizado'})
            return
        self.allowed_origin = origin
        if self.command == 'OPTIONS':
            self.reply(204, None)
            return
        try:
            if self.path == '/state' and self.command == 'GET':
                self.reply(200, self.server.store.state())
            elif self.path == '/health' and self.command == 'GET':
                self.reply(200, {'ok': True, 'database': str(self.server.store.path)})
            elif self.command in ('POST', 'DELETE'):
                size = int(self.headers.get('Content-Length', '0'))
                if size < 0 or size > 1024 * 1024:
                    raise ValueError('Solicitud demasiado grande')
                if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise ValueError('Se requiere application/json')
                data = json.loads(self.rfile.read(size) or '{}')
                self.reply(200, self.server.store.mutate(self.command, self.path, data))
            else:
                self.reply(404, {'error': 'Ruta desconocida'})
        except (ValueError, TypeError, sqlite3.IntegrityError) as exc:
            self.reply(400, {'error': str(exc)})
        except Exception as exc:
            print(f'Error de persistencia: {exc}', file=sys.stderr, flush=True)
            self.reply(500, {'error': 'No se pudo completar la operación en disco. Revisa el servicio y los respaldos.'})

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def reply(self, status, value):
        body = b'' if value is None else json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        if getattr(self, 'allowed_origin', None):
            self.send_header('Access-Control-Allow-Origin', self.allowed_origin)
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    do_GET = handle_request
    do_POST = handle_request
    do_DELETE = handle_request
    do_OPTIONS = handle_request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path)
    parser.add_argument('--port', type=int, default=8791)
    parser.add_argument('--backup', action='store_true')
    parser.add_argument('--restore', type=Path, help='Restaurar con el servicio detenido')
    args = parser.parse_args()
    directory = args.data_dir or default_directory()
    if not directory.is_absolute():
        parser.error('La carpeta de datos debe ser absoluta')
    if args.restore:
        source_path = args.restore.resolve()
        if source_path == (directory / 'fenix_controls.db').resolve():
            parser.error('Selecciona un respaldo distinto de la base activa')
        with sqlite3.connect(source_path.as_uri() + '?mode=ro', uri=True) as source:
            if source.execute('PRAGMA integrity_check').fetchone()[0] != 'ok' or source.execute('PRAGMA user_version').fetchone()[0] != 1:
                parser.error('Respaldo incompatible o dañado')
            if {row[0] for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")} != {'apps', 'logs'}:
                parser.error('El archivo no corresponde a Fenix Controls')
            store = Store(directory)
            try:
                source.backup(store.db)
                print('Restauración completada:', store.path)
            finally:
                store.close()
        return
    store = Store(directory)
    try:
        if args.backup:
            print(store.backup())
            return
        server = HTTPServer(('127.0.0.1', args.port), Handler)
        server.store = store
        print(f'Fenix Controls: http://127.0.0.1:{args.port}\nSQLite: {store.path}', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
    finally:
        store.close()


if __name__ == '__main__':
    main()
