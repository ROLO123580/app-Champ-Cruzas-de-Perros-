# Fenix Controls

Control de proyectos y bitácora con SQLite local. Chrome, Windows y Linux se
conectan al mismo servicio en `http://127.0.0.1:8791`. Los datos no se guardan en
el navegador y no dependen de su puerto. No requiere paquetes Python externos.

## Windows con Ubuntu / WSL

En una terminal Ubuntu, desde este proyecto:

```bash
bash tool/start_service.sh
```

El script obtiene `%LOCALAPPDATA%` de Windows y guarda la base en
`%LOCALAPPDATA%\FenixControls\fenix_controls.db`. Desde WSL corresponde a
`/mnt/c/Users/<usuario>/AppData/Local/FenixControls/fenix_controls.db`.
La ubicación exacta se imprime al iniciar. Mantén esa terminal abierta.
No ejecutes un segundo servicio contra la misma base.

También puedes iniciarlo desde PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File tool/start_service.ps1
```

En otra terminal inicia Flutter:

```bash
flutter pub get
flutter run -d chrome
```

Para la app Linux usa `flutter run -d linux` en WSL. Para la app Windows usa
`flutter run -d windows` desde Windows. Ambas necesitan el servicio iniciado;
Windows accede mediante el reenvío localhost de WSL. Si este reenvío está
deshabilitado hay que habilitarlo antes de usar la app Windows/Chrome Windows.
Chrome debe abrirse desde un origen HTTP local, no desde un sitio público HTTPS.
No se ha configurado inicio automático con Windows.

En Linux sin WSL el servicio usa `~/.local/share/FenixControls`. Para elegir
explícitamente una carpeta persistente (misma carpeta para todos los clientes):

```bash
export FENIX_DATA_DIR=/mnt/c/Users/TU_USUARIO/AppData/Local/FenixControls
bash tool/start_service.sh
```

Para cambiar el puerto: `bash tool/start_service.sh --port 8792` y ejecuta Flutter
con `--dart-define=FENIX_API_URL=http://127.0.0.1:8792`.

## Persistencia y respaldos

Apps y avances se guardan por registro, mediante transacciones SQLite, claves
foráneas y borrado en cascada. La interfaz confirma el guardado después de la
respuesta del servicio. Un error conserva el formulario y se muestra en pantalla;
si hay una interrupción de red, recarga para comprobar el resultado antes de
reintentar. El botón Recargar permite ver cambios de otra ventana.

El servicio crea un respaldo consistente y verificado al iniciar y **antes de
cada escritura** en `respaldos/`. Si el respaldo falla, la escritura se cancela.
El botón de respaldo de la cabecera permite crear otra copia manualmente.
No se eliminan copias automáticamente: vigila el espacio y copia respaldos a
otro disco para protegerte de la pérdida del equipo o del disco.

Para restaurar, cierra las apps y detén el servicio con Ctrl+C. Ejecuta (rutas
absolutas, reemplazando TU_USUARIO y el nombre del respaldo):

```bash
python3 tool/fenix_api.py \
  --data-dir /mnt/c/Users/TU_USUARIO/AppData/Local/FenixControls \
  --restore /mnt/c/Users/TU_USUARIO/AppData/Local/FenixControls/respaldos/fenix-FECHA.db
```

Se valida la copia y se respalda la base actual antes de reemplazar sus datos.
Después vuelve a iniciar el servicio y recarga la app. No reemplaces archivos de
SQLite mientras el servicio está en ejecución. Esta versión parte de una base
nueva; no importa SharedPreferences.

## Validación

```bash
python3 -m unittest discover -s test -p 'test_*.py' -v
flutter analyze
flutter test
flutter build web
```

Las pruebas verifican reinicio, integridad referencial, respaldo/restauración,
fallos de guardado y mensajes de error. Las compilaciones nativas de Windows y
Linux requieren sus herramientas en cada sistema y validación manual.

## Guía paso a paso de SQLite local

Consulta [Inicio y SQLite local](docs/SQLITE_LOCAL.md) para instalar, arrancar los dos servicios, comprobar el guardado y agregar al colaborador. Cada instalación mantiene su base local; GitHub no sincroniza esos datos.
