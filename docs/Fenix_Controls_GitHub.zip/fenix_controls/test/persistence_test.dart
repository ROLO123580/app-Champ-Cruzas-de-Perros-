import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:fenix_controls/apps/app_model.dart';
import 'package:fenix_controls/core/controllers/fenix_controller.dart';
import 'package:fenix_controls/core/data/local_store.dart';

void main() {
  final app = RhApp(
    id: 'champ',
    name: 'Champ',
    type: 'App',
    status: 'Backlog',
    progress: 0,
    priority: 1,
    nextAction: 'Probar',
    targetDate: null,
    createdAt: DateTime(2026),
    updatedAt: DateTime(2026),
  );

  test('A failed write keeps the previous state and reports failure', () async {
    final controller = FenixController(
      store: LocalStore(
        client: MockClient((request) async {
          if (request.method == 'GET') {
            return http.Response(
              jsonEncode({
                'apps': [app.toJson()],
                'logs': [],
              }),
              200,
            );
          }
          return http.Response(jsonEncode({'error': 'Disco lleno'}), 500);
        }),
      ),
    );
    await controller.load();
    expect(controller.apps.single.name, 'Champ');
    expect(await controller.saveApp(app.copyWith(name: 'Cambio')), isFalse);
    expect(controller.apps.single.name, 'Champ');
    expect(controller.saveError, contains('Disco lleno'));
    expect(controller.error, isNull);
    expect(await controller.deleteApp(app.id), isFalse);
    expect(controller.apps, hasLength(1));
    controller.dispose();
  });

  test('Successful writes persist individual records', () async {
    final requests = <http.Request>[];
    final controller = FenixController(
      store: LocalStore(
        client: MockClient((request) async {
          requests.add(request);
          return http.Response(
            jsonEncode(
              request.method == 'GET' ? {'apps': [], 'logs': []} : {'ok': true},
            ),
            200,
          );
        }),
      ),
    );
    await controller.load();
    expect(await controller.saveApp(app), isTrue);
    expect(controller.apps.single.id, 'champ');
    expect(requests.last.url.path, '/apps');
    expect(jsonDecode(requests.last.body)['id'], 'champ');
    expect(
      await controller.addLog(app: app, note: 'Avance', minutes: 15),
      isTrue,
    );
    expect(controller.logs.single.minutes, 15);
    expect(requests.last.url.path, '/logs');
    controller.dispose();
  });

  test('An unavailable service is an error, not an empty database', () async {
    final controller = FenixController(
      store: LocalStore(
        client: MockClient(
          (_) async => throw http.ClientException('Sin conexión'),
        ),
      ),
    );
    await controller.load();
    expect(controller.error, contains('Sin conexión'));
    expect(controller.loading, isFalse);
    controller.dispose();
  });
}
