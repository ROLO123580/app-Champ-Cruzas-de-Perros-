import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import socket
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'tool' / 'fenix_api.py'
spec = importlib.util.spec_from_file_location('fenix_api', SCRIPT)
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)


class PersistenceTest(unittest.TestCase):
    def test_restart_backups_and_restore(self):
        with tempfile.TemporaryDirectory() as folder:
            store = api.Store(folder)
            app = dict(id='champ', name='Champ', type='App', status='Backlog', nextAction='Probar', progress=10, priority=1, targetDate=None, createdAt='2026-10-27T12:00:00Z', updatedAt='2026-10-27T12:00:00Z')
            log = dict(id='log1', appId='champ', appName='Champ', note='Avance ñ', minutes=30, createdAt='2026-10-27T12:00:00Z')
            store.mutate('POST', '/apps', app)
            store.mutate('POST', '/logs', log)
            backup = store.backup()
            store.close()
            store = api.Store(folder)
            self.assertEqual(store.state(), dict(apps=[app], logs=[log]))
            with self.assertRaises(sqlite3.IntegrityError):
                store.mutate('POST', '/logs', dict(log, id='orphan', appId='missing'))
            self.assertEqual(len(store.state()['logs']), 1)
            store.mutate('DELETE', '/apps', {'id': 'champ'})
            self.assertEqual(store.state(), dict(apps=[], logs=[]))
            store.close()
            subprocess.run([sys.executable, str(SCRIPT), '--data-dir', folder, '--restore', backup], check=True, capture_output=True)
            store = api.Store(folder)
            self.assertEqual(store.state(), dict(apps=[app], logs=[log]))
            store.close()
            self.assertGreater(len(list((Path(folder) / 'respaldos').glob('*.db'))), 4)

    def test_http_contract_and_local_origin(self):
        with tempfile.TemporaryDirectory() as folder:
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            process = subprocess.Popen([sys.executable, str(SCRIPT), '--data-dir', folder, '--port', str(port)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            base = f'http://127.0.0.1:{port}'
            try:
                for _ in range(50):
                    try:
                        with urlopen(base + '/health', timeout=1) as response:
                            self.assertTrue(json.load(response)['ok'])
                        break
                    except URLError:
                        time.sleep(0.05)
                else:
                    self.fail('El servicio no inició')
                request = Request(base + '/state', headers={'Origin': 'http://localhost:5000'})
                with urlopen(request) as response:
                    self.assertEqual(response.headers['Access-Control-Allow-Origin'], 'http://localhost:5000')
                    self.assertEqual(json.load(response), {'apps': [], 'logs': []})
                with self.assertRaises(HTTPError) as error:
                    urlopen(Request(base + '/state', headers={'Origin': 'https://example.com'}))
                self.assertEqual(error.exception.code, 403)
                error.exception.close()
                request = Request(base + '/backup', data=b'{}', headers={'Content-Type': 'application/json'}, method='POST')
                with urlopen(request) as response:
                    self.assertTrue(Path(json.load(response)['path']).is_file())
                request = Request(base + '/apps', data=b'{}', headers={'Content-Type': 'application/json'}, method='POST')
                with self.assertRaises(HTTPError) as error:
                    urlopen(request)
                self.assertEqual(error.exception.code, 400)
                error.exception.close()
            finally:
                process.terminate()
                process.wait(timeout=5)

    def test_second_service_cannot_open_the_same_database(self):
        with tempfile.TemporaryDirectory() as folder:
            store = api.Store(folder)
            with self.assertRaises(ValueError):
                api.Store(folder)
            store.close()

    def test_invalid_input_cannot_modify_data(self):
        with tempfile.TemporaryDirectory() as folder:
            store = api.Store(folder)
            for invalid in (None, [], {}, {'id': 'bad'}):
                with self.assertRaises(ValueError):
                    store.mutate('POST', '/apps', invalid)
            self.assertEqual(store.state(), dict(apps=[], logs=[]))
            store.close()

    def test_backup_failure_prevents_delete(self):
        with tempfile.TemporaryDirectory() as folder:
            store = api.Store(folder)
            def fail():
                raise OSError('Disco lleno')
            store.backup = fail
            with self.assertRaises(OSError):
                store.mutate('DELETE', '/apps', {'id': 'any'})
            store.close()


if __name__ == '__main__':
    unittest.main()
