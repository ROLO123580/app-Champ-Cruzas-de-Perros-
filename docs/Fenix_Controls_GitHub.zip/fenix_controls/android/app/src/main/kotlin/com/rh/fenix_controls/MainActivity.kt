package com.rh.fenix_controls

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
