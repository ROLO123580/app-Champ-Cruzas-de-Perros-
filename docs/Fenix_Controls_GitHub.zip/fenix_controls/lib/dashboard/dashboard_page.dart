import 'package:flutter/material.dart';

import '../core/controllers/fenix_controller.dart';
import '../core/utils/date_formatters.dart';
import '../widgets/empty_state.dart';
import '../widgets/metric_card.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.controller});

  final FenixController controller;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 1100
                  ? 4
                  : constraints.maxWidth >= 620
                      ? 2
                      : 1;
              final width = (constraints.maxWidth - ((columns - 1) * 14)) / columns;
              final cards = [
                MetricCard(
                  label: 'Total Apps',
                  value: '${controller.apps.length}',
                  icon: Icons.apps,
                ),
                MetricCard(
                  label: 'En curso',
                  value: '${controller.countByStatus('En curso')}',
                  icon: Icons.play_circle_outline,
                ),
                MetricCard(
                  label: 'Bloqueadas',
                  value: '${controller.countByStatus('Bloqueado')}',
                  icon: Icons.block,
                ),
                MetricCard(
                  label: 'Hechas',
                  value: '${controller.countByStatus('Hecho')}',
                  icon: Icons.check_circle_outline,
                ),
              ];
              return Wrap(
                spacing: 14,
                runSpacing: 14,
                children: cards
                    .map((card) => SizedBox(width: width, child: card))
                    .toList(),
              );
            },
          ),
          const SizedBox(height: 26),
          Text(
            '⚡ Top próximos pasos',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 12),
          if (controller.nextSteps.isEmpty)
            const Card(
              child: SizedBox(
                height: 220,
                child: EmptyState(
                  icon: Icons.bolt_outlined,
                  title: 'Sin próximos pasos',
                  message: 'Crea una App o agrega su siguiente acción.',
                ),
              ),
            )
          else
            ...controller.nextSteps.take(8).map(
                  (app) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    app.name,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(fontWeight: FontWeight.w800),
                                  ),
                                ),
                                _Badge(text: app.type.isEmpty ? 'Sin tipo' : app.type),
                                const SizedBox(width: 8),
                                _Badge(text: 'P${app.priority}'),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 10,
                              runSpacing: 6,
                              children: [
                                Text(app.status),
                                Text('${app.progress}%'),
                                Text('Objetivo: ${formatDate(app.targetDate)}'),
                              ],
                            ),
                            const SizedBox(height: 12),
                            LinearProgressIndicator(value: app.progress / 100),
                            const SizedBox(height: 12),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.arrow_forward, size: 18),
                                const SizedBox(width: 8),
                                Expanded(child: Text(app.nextAction)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: scheme.onSecondaryContainer,
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}
