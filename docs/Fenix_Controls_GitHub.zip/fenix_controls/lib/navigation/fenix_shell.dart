import 'package:flutter/material.dart';

import '../apps/apps_page.dart';
import '../core/controllers/fenix_controller.dart';
import '../dashboard/dashboard_page.dart';
import '../logbook/logbook_page.dart';
import '../reports/reports_page.dart';

class FenixShell extends StatefulWidget {
  const FenixShell({super.key, required this.controller});

  final FenixController controller;

  @override
  State<FenixShell> createState() => _FenixShellState();
}

class _FenixShellState extends State<FenixShell> {
  int index = 0;

  static const titles = ['Dashboard', 'Apps', 'Logbook', 'Reports'];

  Future<void> _backup() async {
    try {
      final path = await widget.controller.backup();
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Respaldo creado: $path')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('No se pudo respaldar: $error')));
    }
  }

  Widget get _actions => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      IconButton(
        tooltip: 'Recargar datos',
        onPressed: widget.controller.load,
        icon: const Icon(Icons.refresh),
      ),
      IconButton(
        tooltip: 'Respaldar base SQLite',
        onPressed: _backup,
        icon: const Icon(Icons.backup_outlined),
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        if (widget.controller.loading) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (widget.controller.error != null) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48),
                    const SizedBox(height: 16),
                    Text(widget.controller.error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: widget.controller.load,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Reintentar'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return LayoutBuilder(
          builder: (context, constraints) {
            final desktop = constraints.maxWidth >= 900;
            final extended = constraints.maxWidth >= 1180;

            final pages = [
              DashboardPage(controller: widget.controller),
              AppsPage(controller: widget.controller),
              LogbookPage(controller: widget.controller),
              ReportsPage(controller: widget.controller),
            ];

            if (desktop) {
              return Scaffold(
                body: SafeArea(
                  child: Row(
                    children: [
                      NavigationRail(
                        extended: extended,
                        minExtendedWidth: 220,
                        selectedIndex: index,
                        onDestinationSelected: (value) {
                          setState(() => index = value);
                        },
                        leading: Padding(
                          padding: const EdgeInsets.fromLTRB(12, 18, 12, 22),
                          child: extended
                              ? const Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.local_fire_department, size: 30),
                                    SizedBox(width: 10),
                                    Text(
                                      'Fenix Controls',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ],
                                )
                              : const Icon(
                                  Icons.local_fire_department,
                                  size: 34,
                                ),
                        ),
                        destinations: const [
                          NavigationRailDestination(
                            icon: Icon(Icons.dashboard_outlined),
                            selectedIcon: Icon(Icons.dashboard),
                            label: Text('Dashboard'),
                          ),
                          NavigationRailDestination(
                            icon: Icon(Icons.apps_outlined),
                            selectedIcon: Icon(Icons.apps),
                            label: Text('Apps'),
                          ),
                          NavigationRailDestination(
                            icon: Icon(Icons.menu_book_outlined),
                            selectedIcon: Icon(Icons.menu_book),
                            label: Text('Logbook'),
                          ),
                          NavigationRailDestination(
                            icon: Icon(Icons.bar_chart_outlined),
                            selectedIcon: Icon(Icons.bar_chart),
                            label: Text('Reports'),
                          ),
                        ],
                      ),
                      const VerticalDivider(width: 1),
                      Expanded(
                        child: Column(
                          children: [
                            _DesktopHeader(
                              title: titles[index],
                              actions: _actions,
                            ),
                            Expanded(
                              child: IndexedStack(
                                index: index,
                                children: pages,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }

            return Scaffold(
              appBar: AppBar(
                actions: [_actions],
                titleSpacing: 16,
                title: Row(
                  children: [
                    const Icon(Icons.local_fire_department),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Fenix Controls · ${titles[index]}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              body: IndexedStack(index: index, children: pages),
              bottomNavigationBar: NavigationBar(
                selectedIndex: index,
                onDestinationSelected: (value) {
                  setState(() => index = value);
                },
                destinations: const [
                  NavigationDestination(
                    icon: Icon(Icons.dashboard_outlined),
                    selectedIcon: Icon(Icons.dashboard),
                    label: 'Dashboard',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.apps_outlined),
                    selectedIcon: Icon(Icons.apps),
                    label: 'Apps',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.menu_book_outlined),
                    selectedIcon: Icon(Icons.menu_book),
                    label: 'Logbook',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.bar_chart_outlined),
                    selectedIcon: Icon(Icons.bar_chart),
                    label: 'Reports',
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _DesktopHeader extends StatelessWidget {
  const _DesktopHeader({required this.title, required this.actions});

  final String title;
  final Widget actions;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 72,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Row(
          children: [
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
            ),
            const Spacer(),
            actions,
            Text(
              'Control de Apps RH',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
