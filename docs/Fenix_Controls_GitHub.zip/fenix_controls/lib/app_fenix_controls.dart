import 'package:flutter/material.dart';

import 'core/controllers/fenix_controller.dart';
import 'core/theme/fenix_theme.dart';
import 'navigation/fenix_shell.dart';

class FenixControlsApp extends StatefulWidget {
  const FenixControlsApp({super.key});

  @override
  State<FenixControlsApp> createState() => _FenixControlsAppState();
}

class _FenixControlsAppState extends State<FenixControlsApp> {
  late final FenixController controller;

  @override
  void initState() {
    super.initState();
    controller = FenixController()..load();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fenix Controls',
      theme: FenixTheme.dark(),
      home: FenixShell(controller: controller),
    );
  }
}
