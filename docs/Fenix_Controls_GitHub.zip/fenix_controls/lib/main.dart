import 'package:flutter/material.dart';

import 'app_fenix_controls.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FenixControlsApp());
}
