import 'package:flutter/material.dart';

import '../core/controllers/fenix_controller.dart';
import '../core/utils/date_formatters.dart';
import '../widgets/empty_state.dart';
import '../widgets/metric_card.dart';

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key, required this.controller});

  final FenixController controller;

  static const statuses = ['Backlog', 'En curso', 'Bloqueado', 'Hecho'];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final wide = constraints.maxWidth >= 700;
              final cardWidth = wide
                  ? (constraints.maxWidth - 14) / 2
                  : constraints.maxWidth;
              return Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  SizedBox(
                    width: cardWidth,
                    child: MetricCard(
                      label: 'Tiempo total en bitácora',
                      value: formatMinutes(controller.totalMinutes),
                      icon: Icons.schedule,
                    ),
                  ),
                  SizedBox(
                    width: cardWidth,
                    child: MetricCard(
                      label: 'Registros de avance',
                      value: '${controller.logs.length}',
                      icon: Icons.menu_book_outlined,
                    ),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 26),
          Text(
            'Proyectos por estado',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: statuses.map((status) {
                  final count = controller.countByStatus(status);
                  final total = controller.apps.isEmpty ? 1 : controller.apps.length;
                  final ratio = count / total;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                status,
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                            Text('$count'),
                          ],
                        ),
                        const SizedBox(height: 7),
                        LinearProgressIndicator(value: ratio),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          const SizedBox(height: 26),
          Text(
            'Últimos 50 registros',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 12),
          if (controller.logs.isEmpty)
            const Card(
              child: SizedBox(
                height: 190,
                child: EmptyState(
                  icon: Icons.table_rows_outlined,
                  title: 'Sin datos para reportar',
                  message: 'Registra avances desde Logbook.',
                ),
              ),
            )
          else
            LayoutBuilder(
              builder: (context, constraints) {
                if (constraints.maxWidth >= 760) {
                  return Card(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('Fecha')),
                          DataColumn(label: Text('App')),
                          DataColumn(label: Text('Minutos')),
                          DataColumn(label: Text('Nota')),
                        ],
                        rows: controller.logs.take(50).map((entry) {
                          return DataRow(
                            cells: [
                              DataCell(Text(formatDateTime(entry.createdAt))),
                              DataCell(Text(entry.appName)),
                              DataCell(Text('${entry.minutes}')),
                              DataCell(
                                SizedBox(
                                  width: 360,
                                  child: Text(
                                    entry.note,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  );
                }

                return Column(
                  children: controller.logs.take(50).map((entry) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          title: Text(entry.appName),
                          subtitle: Text(
                            '${entry.note}\n${formatDateTime(entry.createdAt)}',
                          ),
                          isThreeLine: true,
                          trailing: Text('${entry.minutes} min'),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
        ],
      ),
    );
  }
}
