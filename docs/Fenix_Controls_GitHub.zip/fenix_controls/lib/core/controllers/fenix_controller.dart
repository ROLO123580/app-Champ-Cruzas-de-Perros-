import 'package:flutter/foundation.dart';

import '../../apps/app_model.dart';
import '../../logbook/log_entry_model.dart';
import '../data/local_store.dart';

class FenixController extends ChangeNotifier {
  FenixController({LocalStore? store}) : _store = store ?? LocalStore();

  final LocalStore _store;

  final List<RhApp> _apps = [];
  final List<LogEntry> _logs = [];

  bool _loading = true;
  String? _error;
  String? saveError;

  bool get loading => _loading;
  String? get error => _error;
  List<RhApp> get apps => List.unmodifiable(_apps);
  List<LogEntry> get logs => List.unmodifiable(_logs);

  Future<void> load() async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final state = await _store.load();
      final loadedApps = state.apps;
      final loadedLogs = state.logs;
      _apps
        ..clear()
        ..addAll(loadedApps);
      _logs
        ..clear()
        ..addAll(loadedLogs);
      _sortData();
    } catch (e) {
      _error = 'No se pudieron cargar los datos locales: $e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<bool> _persist(
    Future<void> Function() operation,
    VoidCallback commit,
  ) async {
    try {
      saveError = null;
      await operation();
      commit();
      _sortData();
      notifyListeners();
      return true;
    } catch (error) {
      saveError = 'No se pudo confirmar el guardado: $error';
      notifyListeners();
      return false;
    }
  }

  Future<bool> saveApp(RhApp app) => _persist(() => _store.saveApp(app), () {
    final index = _apps.indexWhere((item) => item.id == app.id);
    if (index == -1) {
      _apps.add(app);
    } else {
      _apps[index] = app;
    }
  });

  Future<bool> deleteApp(String appId) =>
      _persist(() => _store.deleteApp(appId), () {
        _apps.removeWhere((app) => app.id == appId);
        _logs.removeWhere((log) => log.appId == appId);
      });

  Future<bool> addLog({
    required RhApp app,
    required String note,
    required int minutes,
  }) {
    final log = LogEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      appId: app.id,
      appName: app.name,
      note: note.trim(),
      minutes: minutes,
      createdAt: DateTime.now(),
    );
    return _persist(() => _store.saveLog(log), () => _logs.add(log));
  }

  Future<String> backup() => _store.backup();

  @override
  void dispose() {
    _store.close();
    super.dispose();
  }

  int countByStatus(String status) =>
      _apps.where((app) => app.status == status).length;

  int get totalMinutes => _logs.fold<int>(0, (sum, item) => sum + item.minutes);

  List<RhApp> get nextSteps {
    final result = _apps
        .where(
          (app) => app.status != 'Hecho' && app.nextAction.trim().isNotEmpty,
        )
        .toList();
    result.sort((a, b) {
      final byPriority = a.priority.compareTo(b.priority);
      if (byPriority != 0) return byPriority;
      return a.progress.compareTo(b.progress);
    });
    return result;
  }

  void _sortData() {
    _apps.sort((a, b) {
      final byPriority = a.priority.compareTo(b.priority);
      if (byPriority != 0) return byPriority;
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    _logs.sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }
}
