import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../apps/app_model.dart';
import '../../logbook/log_entry_model.dart';

/// Chrome y escritorio utilizan el mismo servicio y la misma base SQLite.
class LocalStore {
  LocalStore({http.Client? client, String? baseUrl})
    : _client = client ?? http.Client(),
      _baseUrl =
          baseUrl ??
          const String.fromEnvironment(
            'FENIX_API_URL',
            defaultValue: 'http://127.0.0.1:8791',
          );

  final http.Client _client;
  final String _baseUrl;

  Future<Map<String, dynamic>> _request(
    String method,
    String path, [
    Map<String, dynamic>? data,
  ]) async {
    try {
      final request = http.Request(method, Uri.parse('$_baseUrl$path'));
      if (data != null) {
        request.headers['Content-Type'] = 'application/json';
        request.body = jsonEncode(data);
      }
      final response = await http.Response.fromStream(
        await _client.send(request).timeout(const Duration(seconds: 15)),
      ).timeout(const Duration(seconds: 15));
      final decoded =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (response.statusCode != 200) {
        throw StateError(decoded['error']?.toString() ?? 'Error del servicio');
      }
      return decoded;
    } catch (error) {
      throw StateError(
        'No se pudo confirmar la operación. Verifica el servicio local en $_baseUrl y recarga antes de reintentar. Detalle: $error',
      );
    }
  }

  Future<({List<RhApp> apps, List<LogEntry> logs})> load() async {
    final state = await _request('GET', '/state');
    return (
      apps: (state['apps'] as List)
          .map((item) => RhApp.fromJson(item as Map<String, dynamic>))
          .toList(),
      logs: (state['logs'] as List)
          .map((item) => LogEntry.fromJson(item as Map<String, dynamic>))
          .toList(),
    );
  }

  Future<void> saveApp(RhApp app) async {
    await _request('POST', '/apps', app.toJson());
  }

  Future<void> deleteApp(String id) async {
    await _request('DELETE', '/apps', {'id': id});
  }

  Future<void> saveLog(LogEntry log) async {
    await _request('POST', '/logs', log.toJson());
  }

  Future<String> backup() async =>
      (await _request('POST', '/backup', {}))['path'] as String;

  void close() => _client.close();
}
