import 'package:flutter/material.dart';

import '../apps/app_model.dart';
import '../core/controllers/fenix_controller.dart';
import '../core/utils/date_formatters.dart';
import '../widgets/empty_state.dart';

class LogbookPage extends StatefulWidget {
  const LogbookPage({super.key, required this.controller});

  final FenixController controller;

  @override
  State<LogbookPage> createState() => _LogbookPageState();
}

class _LogbookPageState extends State<LogbookPage> {
  final formKey = GlobalKey<FormState>();
  final noteController = TextEditingController();
  final minutesController = TextEditingController(text: '30');
  String? selectedAppId;
  bool saving = false;

  @override
  void dispose() {
    noteController.dispose();
    minutesController.dispose();
    super.dispose();
  }

  RhApp? _selectedApp() {
    if (widget.controller.apps.isEmpty) return null;
    final current = selectedAppId;
    if (current != null) {
      for (final app in widget.controller.apps) {
        if (app.id == current) return app;
      }
    }
    return widget.controller.apps.first;
  }

  Future<void> _register() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    final app = _selectedApp();
    if (app == null) return;

    final minutes = int.tryParse(minutesController.text.trim());
    if (minutes == null || minutes <= 0) return;

    setState(() => saving = true);
    final saved = await widget.controller.addLog(
      app: app,
      note: noteController.text,
      minutes: minutes,
    );
    if (!mounted) return;
    setState(() => saving = false);
    if (!saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.controller.saveError ?? 'No se pudo guardar'),
        ),
      );
      return;
    }
    noteController.clear();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Avance registrado')));
  }

  @override
  Widget build(BuildContext context) {
    final apps = widget.controller.apps;
    final currentApp = _selectedApp();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '📝 Logbook',
            style: Theme.of(
              context,
            ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 14),
          if (apps.isEmpty)
            const Card(
              child: SizedBox(
                height: 220,
                child: EmptyState(
                  icon: Icons.menu_book_outlined,
                  title: 'Aún no hay Apps',
                  message: 'Crea una App antes de registrar avances.',
                ),
              ),
            )
          else
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final wide = constraints.maxWidth >= 720;
                          final appField = DropdownButtonFormField<String>(
                            key: ValueKey(currentApp?.id),
                            initialValue: currentApp?.id,
                            decoration: const InputDecoration(
                              labelText: 'App',
                              prefixIcon: Icon(Icons.apps),
                            ),
                            items: apps
                                .map(
                                  (app) => DropdownMenuItem(
                                    value: app.id,
                                    child: Text(
                                      app.name,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (value) {
                              setState(() => selectedAppId = value);
                            },
                          );

                          final minutesField = TextFormField(
                            controller: minutesController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Minutos invertidos',
                              prefixIcon: Icon(Icons.timer_outlined),
                            ),
                            validator: (value) {
                              final parsed = int.tryParse(value?.trim() ?? '');
                              if (parsed == null || parsed <= 0) {
                                return 'Ingresa minutos válidos';
                              }
                              return null;
                            },
                          );

                          if (wide) {
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(flex: 2, child: appField),
                                const SizedBox(width: 14),
                                Expanded(child: minutesField),
                              ],
                            );
                          }

                          return Column(
                            children: [
                              appField,
                              const SizedBox(height: 14),
                              minutesField,
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: noteController,
                        minLines: 3,
                        maxLines: 5,
                        decoration: const InputDecoration(
                          labelText: '¿Qué hiciste?',
                          hintText: 'Resultado en 1–3 líneas',
                          alignLabelWithHint: true,
                          prefixIcon: Icon(Icons.edit_note),
                        ),
                        validator: (value) =>
                            value == null || value.trim().isEmpty
                            ? 'Describe brevemente el avance'
                            : null,
                      ),
                      const SizedBox(height: 18),
                      Align(
                        alignment: Alignment.centerRight,
                        child: FilledButton.icon(
                          onPressed: saving ? null : _register,
                          icon: saving
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.add_task),
                          label: const Text('Registrar avance'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SizedBox(height: 26),
          Row(
            children: [
              Expanded(
                child: Text(
                  '📚 Historial',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                ),
              ),
              Text('${widget.controller.logs.length} registros'),
            ],
          ),
          const SizedBox(height: 12),
          if (widget.controller.logs.isEmpty)
            const Card(
              child: SizedBox(
                height: 190,
                child: EmptyState(
                  icon: Icons.history,
                  title: 'Sin registros todavía',
                  message: 'Tus avances aparecerán aquí.',
                ),
              ),
            )
          else
            ...widget.controller.logs
                .take(100)
                .map(
                  (entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 10,
                        ),
                        leading: CircleAvatar(child: Text('${entry.minutes}')),
                        title: Text(
                          entry.appName,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(entry.note),
                              const SizedBox(height: 5),
                              Text(
                                '${formatDateTime(entry.createdAt)} · ${formatMinutes(entry.minutes)}',
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}
