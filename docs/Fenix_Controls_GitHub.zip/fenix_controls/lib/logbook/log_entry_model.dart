class LogEntry {
  const LogEntry({
    required this.id,
    required this.appId,
    required this.appName,
    required this.note,
    required this.minutes,
    required this.createdAt,
  });

  final String id;
  final String appId;
  final String appName;
  final String note;
  final int minutes;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'appId': appId,
        'appName': appName,
        'note': note,
        'minutes': minutes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory LogEntry.fromJson(Map<String, dynamic> json) {
    return LogEntry(
      id: json['id'] as String,
      appId: json['appId'] as String? ?? '',
      appName: json['appName'] as String? ?? '',
      note: json['note'] as String? ?? '',
      minutes: (json['minutes'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}
