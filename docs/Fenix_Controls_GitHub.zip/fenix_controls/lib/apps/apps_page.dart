import 'package:flutter/material.dart';

import '../core/controllers/fenix_controller.dart';
import '../core/utils/date_formatters.dart';
import '../widgets/empty_state.dart';
import 'app_form.dart';
import 'app_model.dart';

class AppsPage extends StatefulWidget {
  const AppsPage({super.key, required this.controller});

  final FenixController controller;

  @override
  State<AppsPage> createState() => _AppsPageState();
}

class _AppsPageState extends State<AppsPage> {
  final searchController = TextEditingController();
  String? selectedId;
  bool creating = false;

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  List<RhApp> get filteredApps {
    final query = searchController.text.trim().toLowerCase();
    if (query.isEmpty) return widget.controller.apps;
    return widget.controller.apps.where((app) {
      return app.name.toLowerCase().contains(query) ||
          app.type.toLowerCase().contains(query) ||
          app.status.toLowerCase().contains(query);
    }).toList();
  }

  RhApp? get selectedApp {
    if (selectedId == null) return null;
    for (final app in widget.controller.apps) {
      if (app.id == selectedId) return app;
    }
    return null;
  }

  void _showSaveError() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(widget.controller.saveError ?? 'No se pudo guardar'),
        duration: const Duration(seconds: 10),
      ),
    );
  }

  Future<void> _saveDesktop(RhApp app) async {
    if (!await widget.controller.saveApp(app)) {
      _showSaveError();
      return;
    }
    if (!mounted) return;
    setState(() {
      selectedId = app.id;
      creating = false;
    });
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('App guardada')));
  }

  Future<void> _deleteDesktop(RhApp app) async {
    if (!await widget.controller.deleteApp(app.id)) {
      _showSaveError();
      return;
    }
    if (!mounted) return;
    setState(() {
      selectedId = null;
      creating = false;
    });
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('App eliminada')));
  }

  Future<void> _openMobileEditor(RhApp? app) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (sheetContext) {
        return FractionallySizedBox(
          heightFactor: 0.94,
          child: AppForm(
            initial: app,
            onCancel: () => Navigator.pop(sheetContext),
            onSave: (saved) async {
              if (!await widget.controller.saveApp(saved)) {
                _showSaveError();
                return;
              }
              if (sheetContext.mounted) Navigator.pop(sheetContext);
              if (mounted) {
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(const SnackBar(content: Text('App guardada')));
              }
            },
            onDelete: app == null
                ? null
                : (deleted) async {
                    if (!await widget.controller.deleteApp(deleted.id)) {
                      _showSaveError();
                      return;
                    }
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('App eliminada')),
                      );
                    }
                  },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final split = constraints.maxWidth >= 820;
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: searchController,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        hintText: 'Buscar por nombre, tipo o estado',
                        prefixIcon: Icon(Icons.search),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    onPressed: split
                        ? () => setState(() {
                            creating = true;
                            selectedId = null;
                          })
                        : () => _openMobileEditor(null),
                    icon: const Icon(Icons.add),
                    label: Text(split ? 'Nueva App' : 'Nueva'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: split
                    ? Row(
                        children: [
                          Expanded(
                            flex: 5,
                            child: _AppList(
                              apps: filteredApps,
                              selectedId: selectedId,
                              onTap: (app) => setState(() {
                                selectedId = app.id;
                                creating = false;
                              }),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            flex: 5,
                            child: Card(
                              clipBehavior: Clip.antiAlias,
                              child: creating || selectedApp != null
                                  ? AppForm(
                                      key: ValueKey(
                                        creating ? 'new' : selectedApp!.id,
                                      ),
                                      initial: creating ? null : selectedApp,
                                      onSave: _saveDesktop,
                                      onDelete: creating
                                          ? null
                                          : _deleteDesktop,
                                      onCancel: () => setState(() {
                                        creating = false;
                                        selectedId = null;
                                      }),
                                    )
                                  : const EmptyState(
                                      icon: Icons.touch_app_outlined,
                                      title: 'Selecciona una App',
                                      message:
                                          'Elige una App para editarla o crea una nueva.',
                                    ),
                            ),
                          ),
                        ],
                      )
                    : _AppList(
                        apps: filteredApps,
                        selectedId: null,
                        onTap: _openMobileEditor,
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AppList extends StatelessWidget {
  const _AppList({
    required this.apps,
    required this.selectedId,
    required this.onTap,
  });

  final List<RhApp> apps;
  final String? selectedId;
  final void Function(RhApp app) onTap;

  @override
  Widget build(BuildContext context) {
    if (apps.isEmpty) {
      return const Card(
        child: EmptyState(
          icon: Icons.apps_outlined,
          title: 'No hay Apps',
          message: 'Crea la primera App de Fenix Controls.',
        ),
      );
    }

    return ListView.separated(
      itemCount: apps.length,
      separatorBuilder: (_, _) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final app = apps[index];
        final selected = app.id == selectedId;
        final scheme = Theme.of(context).colorScheme;
        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => onTap(app),
            child: Container(
              decoration: selected
                  ? BoxDecoration(
                      border: Border.all(color: scheme.primary, width: 2),
                      borderRadius: BorderRadius.circular(18),
                    )
                  : null,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          app.name,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: scheme.primaryContainer,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'P${app.priority}',
                          style: TextStyle(color: scheme.onPrimaryContainer),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('${app.type} · ${app.status}'),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: app.progress / 100),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('${app.progress}%'),
                      const Spacer(),
                      Text(formatDate(app.targetDate)),
                    ],
                  ),
                  if (app.nextAction.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      '→ ${app.nextAction}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
