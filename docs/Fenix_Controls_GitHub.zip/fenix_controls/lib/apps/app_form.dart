import 'package:flutter/material.dart';

import 'app_model.dart';
import '../core/utils/date_formatters.dart';

class AppForm extends StatefulWidget {
  const AppForm({
    super.key,
    required this.initial,
    required this.onSave,
    this.onDelete,
    this.onCancel,
  });

  final RhApp? initial;
  final Future<void> Function(RhApp app) onSave;
  final Future<void> Function(RhApp app)? onDelete;
  final VoidCallback? onCancel;

  @override
  State<AppForm> createState() => _AppFormState();
}

class _AppFormState extends State<AppForm> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController nameController;
  late final TextEditingController typeController;
  late final TextEditingController nextActionController;

  late String status;
  late double progress;
  late int priority;
  DateTime? targetDate;
  bool saving = false;

  static const statuses = ['Backlog', 'En curso', 'Bloqueado', 'Hecho'];

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController();
    typeController = TextEditingController();
    nextActionController = TextEditingController();
    _load(widget.initial);
  }

  @override
  void didUpdateWidget(covariant AppForm oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initial?.id != widget.initial?.id) {
      _load(widget.initial);
    }
  }

  void _load(RhApp? app) {
    nameController.text = app?.name ?? '';
    typeController.text = app?.type ?? '';
    nextActionController.text = app?.nextAction ?? '';
    status = app?.status ?? 'Backlog';
    progress = (app?.progress ?? 0).toDouble();
    priority = app?.priority ?? 3;
    targetDate = app?.targetDate;
  }

  @override
  void dispose() {
    nameController.dispose();
    typeController.dispose();
    nextActionController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: targetDate ?? now,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 10),
    );
    if (date != null) {
      setState(() => targetDate = date);
    }
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false)) return;

    setState(() => saving = true);
    final now = DateTime.now();
    final app = RhApp(
      id: widget.initial?.id ?? now.microsecondsSinceEpoch.toString(),
      name: nameController.text.trim(),
      type: typeController.text.trim(),
      status: status,
      progress: progress.round(),
      priority: priority,
      nextAction: nextActionController.text.trim(),
      targetDate: targetDate,
      createdAt: widget.initial?.createdAt ?? now,
      updatedAt: now,
    );

    await widget.onSave(app);
    if (!mounted) return;
    setState(() => saving = false);
  }

  Future<void> _delete() async {
    final current = widget.initial;
    if (current == null || widget.onDelete == null) return;

    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Eliminar App'),
            content: Text(
              '¿Eliminar “${current.name}”? También se eliminarán sus registros del Logbook.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancelar'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Eliminar'),
              ),
            ],
          ),
        ) ??
        false;

    if (!confirmed) return;
    await widget.onDelete!(current);
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.initial != null;
    return Form(
      key: formKey,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    isEditing ? 'Editar App' : 'Crear App',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                ),
                if (widget.onCancel != null)
                  IconButton(
                    onPressed: widget.onCancel,
                    tooltip: 'Cerrar',
                    icon: const Icon(Icons.close),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nombre de la App',
                prefixIcon: Icon(Icons.apps),
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Escribe el nombre de la App'
                  : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: typeController,
              decoration: const InputDecoration(
                labelText: 'Tipo',
                hintText: 'Ej: Fitness, Productividad, Documentos…',
                prefixIcon: Icon(Icons.category_outlined),
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Indica el tipo de App'
                  : null,
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              initialValue: status,
              decoration: const InputDecoration(
                labelText: 'Estado',
                prefixIcon: Icon(Icons.flag_outlined),
              ),
              items: statuses
                  .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                  .toList(),
              onChanged: (value) {
                if (value != null) setState(() => status = value);
              },
            ),
            const SizedBox(height: 18),
            Text(
              'Avance: ${progress.round()}%',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            Slider(
              value: progress,
              min: 0,
              max: 100,
              divisions: 20,
              label: '${progress.round()}%',
              onChanged: (value) => setState(() => progress = value),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<int>(
              initialValue: priority,
              decoration: const InputDecoration(
                labelText: 'Prioridad (1 = alta)',
                prefixIcon: Icon(Icons.priority_high),
              ),
              items: List.generate(
                5,
                (index) => DropdownMenuItem(
                  value: index + 1,
                  child: Text('${index + 1}'),
                ),
              ),
              onChanged: (value) {
                if (value != null) setState(() => priority = value);
              },
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: nextActionController,
              maxLines: 3,
              minLines: 2,
              decoration: const InputDecoration(
                labelText: 'Siguiente acción',
                hintText: 'Una acción concreta en 1–3 líneas',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.arrow_forward),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: ListTile(
                leading: const Icon(Icons.event_outlined),
                title: const Text('Fecha objetivo'),
                subtitle: Text(formatDate(targetDate)),
                trailing: Wrap(
                  spacing: 4,
                  children: [
                    if (targetDate != null)
                      IconButton(
                        onPressed: () => setState(() => targetDate = null),
                        tooltip: 'Quitar fecha',
                        icon: const Icon(Icons.clear),
                      ),
                    IconButton(
                      onPressed: _pickDate,
                      tooltip: 'Elegir fecha',
                      icon: const Icon(Icons.calendar_month),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: saving ? null : _save,
                icon: saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.save_outlined),
                label: Text(isEditing ? 'Guardar cambios' : 'Crear App'),
              ),
            ),
            if (isEditing && widget.onDelete != null) ...[
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: saving ? null : _delete,
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Eliminar App'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
