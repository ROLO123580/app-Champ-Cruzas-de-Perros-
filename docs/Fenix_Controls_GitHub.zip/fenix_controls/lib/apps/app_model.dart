class RhApp {
  const RhApp({
    required this.id,
    required this.name,
    required this.type,
    required this.status,
    required this.progress,
    required this.priority,
    required this.nextAction,
    required this.targetDate,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String name;
  final String type;
  final String status;
  final int progress;
  final int priority;
  final String nextAction;
  final DateTime? targetDate;
  final DateTime createdAt;
  final DateTime updatedAt;

  RhApp copyWith({
    String? id,
    String? name,
    String? type,
    String? status,
    int? progress,
    int? priority,
    String? nextAction,
    DateTime? targetDate,
    bool clearTargetDate = false,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return RhApp(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      status: status ?? this.status,
      progress: progress ?? this.progress,
      priority: priority ?? this.priority,
      nextAction: nextAction ?? this.nextAction,
      targetDate: clearTargetDate ? null : (targetDate ?? this.targetDate),
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'status': status,
        'progress': progress,
        'priority': priority,
        'nextAction': nextAction,
        'targetDate': targetDate?.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory RhApp.fromJson(Map<String, dynamic> json) {
    return RhApp(
      id: json['id'] as String,
      name: json['name'] as String? ?? '',
      type: json['type'] as String? ?? '',
      status: json['status'] as String? ?? 'Backlog',
      progress: (json['progress'] as num?)?.toInt() ?? 0,
      priority: (json['priority'] as num?)?.toInt() ?? 3,
      nextAction: json['nextAction'] as String? ?? '',
      targetDate: json['targetDate'] == null
          ? null
          : DateTime.tryParse(json['targetDate'] as String),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}
