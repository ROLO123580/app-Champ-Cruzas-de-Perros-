import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]


class HttpTest(unittest.TestCase):
    def test_http_guardado_reinicio_y_origen(self):
        with tempfile.TemporaryDirectory() as folder:
            with socket.socket() as s:
                s.bind(('127.0.0.1', 0))
                port = s.getsockname()[1]
            url = f'http://127.0.0.1:{port}'

            def iniciar():
                env = dict(os.environ)
                for key in ('TURSO_DATABASE_URL', 'TURSO_AUTH_TOKEN', 'FENIX_CATALOGO_ID'):
                    env.pop(key, None)
                p = subprocess.Popen([sys.executable, str(ROOT / 'tool/nutricion_api.py'),
                                      '--data-dir', folder, '--port', str(port)],
                                     env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                for _ in range(60):
                    if p.poll() is not None:
                        self.fail('El servicio no pudo iniciar')
                    try:
                        with urlopen(url + '/estado', timeout=.3):
                            return p
                    except (URLError, TimeoutError):
                        time.sleep(.05)
                p.terminate(); p.wait(timeout=5)
                self.fail('Tiempo de inicio excedido')

            p = iniciar()
            try:
                datos = {'ficha': {'nombre': 'Arroz', 'aliases_voz': ['arroz blanco'],
                    'calorias_100g': 130, 'proteinas_100g': 2.7, 'carbohidratos_100g': 28, 'grasas_100g': .3}}
                req = Request(url + '/fichas', json.dumps(datos).encode(), {'Content-Type': 'application/json'})
                with urlopen(req) as response:
                    id_ficha = json.load(response)['id']
                with self.assertRaises(HTTPError) as error:
                    urlopen(Request(url + '/fichas', headers={'Origin': 'https://externo.example'}))
                self.assertEqual(error.exception.code, 403)
                error.exception.close()
            finally:
                p.terminate(); p.wait(timeout=5)
            p = iniciar()
            try:
                with urlopen(url + '/fichas') as response:
                    self.assertEqual(json.load(response)['fichas'][0]['id'], id_ficha)
            finally:
                p.terminate(); p.wait(timeout=5)


if __name__ == '__main__': unittest.main()
