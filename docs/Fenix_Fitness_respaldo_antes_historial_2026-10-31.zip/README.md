# Fenix Fitness

Seguimiento de consumos, gastos y objetivos. El módulo **Registro nutricional**
permite editar fichas, confirmar porciones y usar foto o voz como asistencia.

Inicio y configuración: [Registro nutricional](docs/registro_nutricional.md).
El servicio Python mantiene SQLite local. Turso y Gemini son opcionales y
requieren configuración en el servicio; sus secretos no se incluyen en Flutter.

```bash
python3 tool/nutricion_api.py
flutter run -d chrome
```

Para OpenCV instalar primero las dependencias indicadas en la documentación.
El Login existente es visual; no acredita una sesión autenticada.
