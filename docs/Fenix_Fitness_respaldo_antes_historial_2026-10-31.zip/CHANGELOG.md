# Cambios

## 2026-10-29 — Registro nutricional inicial

- Microapp integrada al final del menú y tres NanoApps: editor, foto y voz.
- SQLite versionado para fichas y porciones con snapshots e idempotencia.
- Sincronización Turso explícita con cola persistente y detección de conflictos.
- Preprocesado OpenCV, histograma HSV y candidatos revisables por color.
- Adaptador Gemini para audio/texto y JSON estructurado validado.
- Permisos de micrófono/cámara y configuración Android debug para servicio local.
- Validación: analizador Flutter y build web correctos; pruebas del backend y UI
  descritas en docs/registro_nutricional.md. Servicios externos probados con dobles
  de transporte; credenciales y dispositivos reales pendientes.

## 2026 10 14
Documentación inicial v0.1. Estado y propuestas diferenciados; capturas pendientes.
