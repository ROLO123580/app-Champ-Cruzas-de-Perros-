# Registro nutricional — Fenix Fitness

Entrega: 29-10-2026. Módulo añadido al final del menú, conservando los índices
anteriores y la entrada Login existente (que sigue siendo una entrada visual).

## Ejecutar

Desde la raíz de **Fenix Fitness**, en una terminal Ubuntu/WSL:

```bash
python3 -m venv /tmp/fenix-nutricion-venv
/tmp/fenix-nutricion-venv/bin/pip install -r tool/nutricion/requirements.txt
/tmp/fenix-nutricion-venv/bin/python tool/nutricion_api.py
```

En otra terminal:

```bash
flutter pub get
flutter run -d chrome
```

Abrir Login, entrar y elegir **Registro nutricional**. El servicio usa
`127.0.0.1:8793` y `~/.local/share/RHIA/FenixFitness/nutricion/nutricion.db`.
`--data-dir` cambia la carpeta, `--port` cambia el puerto, y
`--dart-define=FENIX_NUTRICION_API=http://127.0.0.1:PUERTO` cambia el cliente.
No usa ni migra los prototipos guardados en Champ. Una sola instancia de servicio
debe administrar cada carpeta de datos. Para respaldar esta primera versión,
detener el servicio y copiar la carpeta completa a otro dispositivo.

## Arquitectura y archivos

```text
lib/app_fenix_fitness.dart -> core/catalogo_pantallas.dart
  microapps/registro_nutricional/app_registro_nutricional.dart
    nanoapps/editor_ficha/app_editor_ficha.dart
      nanofunciones/guardar_ficha/guardar_ficha.dart
        nanoactividades/calcular_macros.dart
    nanoapps/captura_foto/app_captura_foto.dart
      nanofunciones/procesar_foto/procesar_foto.dart
    nanoapps/registro_voz/app_registro_voz.dart
      nanofunciones/procesar_voz/procesar_voz.dart
        nanoactividades/{normalizar_texto,codificar_wav}.dart
  core/nutricion/{api_nutricion,confirmar_porcion}.dart
tool/nutricion_api.py                 adaptador HTTP local
tool/nutricion/actividades.py         cálculo, normalización y validación puros
tool/nutricion/vision.py              preprocesado e histograma OpenCV reales
tool/nutricion/servicios.py           SQLite, sincronización Turso y Gemini
database/registro_nutricional.sql     tabla compartida SQLite / Turso
```

Las pantallas delegan en NanoFunciones y estas en el servicio. OpenCV y los
secretos se ejecutan en el servicio local Python, siguiendo el patrón de servicio
local ya usado por Fenix Controls. Flutter usa bytes, no `dart:io File`, para
mantener compatibilidad web. Extraer un histograma desde un archivo implica E/S:
por eso el adaptador lee los bytes y el cálculo recibe matrices en memoria.

## Casos implementados

- Crear y editar fichas con validación, aliases normalizados y foto opcional.
  Guardado local transaccional; las ediciones obsoletas se rechazan.
- Elegir una ficha manualmente, escribir gramos, revisar macros y confirmar.
  Cada porción guarda una instantánea de macros y versión. Un reintento de la
  misma confirmación no duplica la porción. Las porciones son locales.
- Capturar foto con el selector de cámara del dispositivo o elegir galería.
  Ajustar margen de ROI central, ejecutar balance de blancos acotado y GrabCut,
  revisar overlay verde y elegir entre hasta tres candidatos por distancia entre
  histogramas HSV de 16 × 16 bins normalizados. No hay segmentación de vídeo en
  vivo ni reconocimiento semántico de alimentos; una similitud de color puede
  sugerir alimentos distintos. Los gramos siempre se introducen manualmente.
- Grabar hasta 30 segundos de PCM mono 16 kHz, convertir a WAV y enviar a Gemini,
  o enviar texto escrito. Se muestra la interpretación estructurada editable,
  no una transcripción literal completa del audio. El audio no se guarda en disco.
- Parsear `{alimento, gramos}` con schema y validación posterior: sin peso
  explícito o con varios alimentos pide aclaración. Las coincidencias de aliases
  son exactas después de normalizar, sin comodines SQL ni coincidencias parciales.
  Un alias ambiguo obliga a elegir la ficha antes de registrar.

## Turso

Configurar en el entorno del **servicio**, fuera de Flutter y del repositorio:

```text
TURSO_DATABASE_URL=libsql://TU_BASE.turso.io
TURSO_AUTH_TOKEN=TOKEN_DE_BASE
FENIX_CATALOGO_ID=IDENTIFICADOR_COMPARTIDO_ENTRE_TUS_EQUIPOS
```

No se proporcionan credenciales de ejemplo utilizables. Para sincronizar dos
equipos configurar el mismo catálogo **antes de crear sus bases**. Sin variable,
se genera un catálogo local estable. No cambiar un catálogo ya inicializado.

El botón **Sincronizar Turso** crea el esquema remoto si falta, envía pendientes
y descarga fichas del catálogo. Es sincronización explícita de aplicación mediante
HTTP; no una réplica embebida automática ni sincronización de archivos.
Las fotos se procesan y descartan; se sincroniza su descriptor, no la foto.
No hay borrado de fichas en esta versión, por lo que no hay tombstones.

Cada modificación recibe una versión UUID. El envío usa comparación con la
versión remota base y verifica la confirmación. Un reintento tras perder la
respuesta reconoce la versión ya enviada. Ante ediciones concurrentes se conserva
la local pendiente y se informa su ID; no se resuelven automáticamente. La
resolución manual de conflictos y la descarga paginada quedan pendientes.
Con una caída durante sincronización puede completarse solo parte del lote;
las filas pendientes permiten reintentar. Ningún fallo de nube revierte una ficha
local ya confirmada.

## Gemini

Configurar `GEMINI_API_KEY` y `GEMINI_MODEL` en el servicio. Elegir un modelo
disponible en la cuenta con soporte de audio y salida estructurada. El adaptador
usa `v1beta/models/{modelo}:generateContent` y `responseJsonSchema`.
No se fijó un modelo ni se hicieron llamadas pagadas. El botón de voz envía el
audio a Google; el modo texto envía el texto. La confirmación de porción sigue
siendo explícita y el parser no inventa gramos para “un plato” o “una taza”.

## API local

| Ruta | Uso |
| --- | --- |
| GET /estado | Estado de configuración de Turso y Gemini |
| GET /fichas | Catálogo local |
| POST /fichas | `{ficha, foto?: base64, roi?: [x,y,w,h]}` |
| POST /foto | `{foto: base64, roi: [x,y,w,h]}` → overlay, histograma, candidatos |
| POST /voz | `{texto}` o `{audio: base64, mime}` → interpretación y coincidencias |
| POST /porciones | `{ficha_id, version, gramos, solicitud_id}` → confirmación idempotente |
| POST /sincronizar | Enviar pendientes y descargar catálogo |

Máximo 8 MB por foto/audio y 20 MP por foto; procesamiento reducido a 900 px.
El servicio escucha solo en loopback, valida Host/Origin y no expone secretos.
Es un servicio de **un perfil local**, sin autenticación multiusuario ni aislamiento
por cuenta. El catálogo no es una credencial ni sustituye permisos de Turso.
Para usuarios remotos se requiere un backend autenticado; no publicar este puerto.

## Plataformas y verificación

Chrome requiere origen local seguro para permisos de micrófono. En Android de
desarrollo se añadieron permiso de micrófono y HTTP en el manifiesto debug;
`adb reverse tcp:8793 tcp:8793` permite llegar al servicio desde un dispositivo
conectado por USB. Esto no equivale a un despliegue Android independiente.
iOS/macOS incluyen descripciones de permisos; macOS incluye audio y red saliente.
La cámara en escritorio depende del soporte de image_picker y puede requerir
galería. No se certifican builds nativos ni permisos reales sin dispositivos.

Validación realizada en copia de trabajo temporal antes de integrar:

```bash
flutter analyze --no-pub
flutter test --no-pub
flutter build web --no-pub
/tmp/fenix-nutricion-venv/bin/python -m unittest discover -s test -p 'test_*.py' -v
```

Pruebas de SQLite real, persistencia después de reinicio de proceso HTTP,
idempotencia de porciones, snapshots de macros, conflictos usando un doble de
transporte con SQL real, payloads Turso/Gemini con red sustituida, cálculo OpenCV
real sobre imagen sintética, cálculo Dart y formularios de confirmación/error.
Falta verificar Turso/Gemini con credenciales reales y cámara/micrófono físicos.

Referencias consultadas: [SQL HTTP de Turso](https://docs.turso.tech/sdk/http/reference),
[salida estructurada Gemini](https://ai.google.dev/gemini-api/docs/structured-output),
[GrabCut de OpenCV](https://docs.opencv.org/4.x/d8/d83/tutorial_py_grabcut.html).
