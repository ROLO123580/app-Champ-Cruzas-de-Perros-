import 'package:flutter/material.dart';

import 'core/catalogo_pantallas.dart';
import 'nanoapps/login/app_login.dart';
import 'sidebar/app_sidebar.dart';

class FenixFitnessApp extends StatelessWidget {
  const FenixFitnessApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Fénix Fitness',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2456A6)),
    ),
    home: const Entrada(),
  );
}

class FenixFitnessShell extends StatefulWidget {
  const FenixFitnessShell({super.key});
  @override
  State<FenixFitnessShell> createState() => _FenixFitnessShellState();
}

class _FenixFitnessShellState extends State<FenixFitnessShell> {
  int seleccion = 0;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final escritorio = constraints.maxWidth >= 900;
      return Scaffold(
        appBar: AppBar(title: const Text('Fénix Fitness')),
        drawer: escritorio
            ? null
            : Drawer(
                child: AppSidebar(
                  seleccion: seleccion,
                  onSeleccion: (index) {
                    setState(() => seleccion = index);
                    Navigator.of(context).pop();
                  },
                ),
              ),
        body: Row(
          children: [
            if (escritorio) ...[
              SizedBox(
                width: 320,
                child: AppSidebar(
                  seleccion: seleccion,
                  onSeleccion: (index) => setState(() => seleccion = index),
                ),
              ),
              const VerticalDivider(width: 1),
            ],
            Expanded(child: pantallas[seleccion]),
          ],
        ),
      );
    },
  );
}

class Entrada extends StatelessWidget {
  const Entrada({super.key});
  @override
  Widget build(BuildContext context) => AppLogin(
    nombreApp: 'Fénix Fitness',
    onEntrar: () => Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => const FenixFitnessShell()),
    ),
  );
}
