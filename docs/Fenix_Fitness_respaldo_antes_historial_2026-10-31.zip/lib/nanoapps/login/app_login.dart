import 'package:flutter/material.dart';

class AppLogin extends StatelessWidget {
  const AppLogin({super.key, required this.nombreApp, required this.onEntrar});
  final String nombreApp;
  final VoidCallback onEntrar;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(nombreApp)),
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Login', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 24),
          FilledButton(onPressed: onEntrar, child: const Text('Entrar')),
        ],
      ),
    ),
  );
}
