import 'dart:math';

import 'package:flutter/material.dart';

import '../../nanoapps/editor_ficha/nanofunciones/guardar_ficha/nanoactividades/calcular_macros.dart';
import 'api_nutricion.dart';

class ConfirmarPorcion extends StatefulWidget {
  const ConfirmarPorcion({
    super.key,
    required this.api,
    required this.ficha,
    this.gramos = 100,
  });
  final ApiNutricion api;
  final Map<String, dynamic> ficha;
  final double gramos;
  @override
  State<ConfirmarPorcion> createState() => _ConfirmarPorcionState();
}

class _ConfirmarPorcionState extends State<ConfirmarPorcion> {
  late final TextEditingController gramos;
  bool ocupado = false;
  bool confirmado = false;
  String? error;
  final solicitudId = List.generate(
    16,
    (_) => Random.secure().nextInt(256),
  ).map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  @override
  void initState() {
    super.initState();
    gramos = TextEditingController(text: widget.gramos.toString());
  }

  @override
  void dispose() {
    gramos.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cantidad = double.tryParse(gramos.text.replaceAll(',', '.'));
    Map<String, double>? macros;
    try {
      if (cantidad != null) {
        macros = nanoActividadCalcularMacrosPorPorcion(cantidad, widget.ficha);
      }
    } on ArgumentError {
      /* El botón se deshabilita hasta corregir la porción. */
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.ficha['nombre'] as String,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            TextField(
              controller: gramos,
              enabled: !ocupado && !confirmado,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'Porción en gramos'),
              onChanged: (_) => setState(() {}),
            ),
            if (macros != null)
              Text(
                'Energía: ${macros['calorias']!.toStringAsFixed(1)} kcal\n'
                'Proteínas: ${macros['proteinas']!.toStringAsFixed(1)} g · '
                'Carbohidratos: ${macros['carbohidratos']!.toStringAsFixed(1)} g · '
                'Grasas: ${macros['grasas']!.toStringAsFixed(1)} g',
              ),
            if (error != null)
              Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            if (confirmado) const Text('Porción guardada en este equipo.'),
            FilledButton(
              onPressed: macros == null || ocupado || confirmado
                  ? null
                  : () async {
                      setState(() {
                        ocupado = true;
                        error = null;
                      });
                      try {
                        await widget.api.solicitar('/porciones', {
                          'ficha_id': widget.ficha['id'],
                          'version': widget.ficha['version'],
                          'gramos': cantidad,
                          'solicitud_id': solicitudId,
                        });
                        if (mounted) {
                          setState(() => confirmado = true);
                        }
                      } catch (e) {
                        if (mounted) {
                          setState(() => error = e.toString());
                        }
                      } finally {
                        if (mounted) {
                          setState(() => ocupado = false);
                        }
                      }
                    },
              child: Text(ocupado ? 'Guardando…' : 'Confirmar porción'),
            ),
          ],
        ),
      ),
    );
  }
}
