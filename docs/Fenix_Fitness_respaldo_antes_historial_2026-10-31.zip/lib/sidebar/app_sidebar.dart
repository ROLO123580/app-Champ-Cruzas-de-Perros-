import 'package:flutter/material.dart';

import '../core/catalogo_pantallas.dart';

class AppSidebar extends StatelessWidget {
  const AppSidebar({
    super.key,
    required this.seleccion,
    required this.onSeleccion,
  });
  final int seleccion;
  final ValueChanged<int> onSeleccion;

  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface,
    child: SafeArea(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(24),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Fénix Fitness',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              itemCount: titulos.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: ListTile(
                  leading: SizedBox(
                    width: 24,
                    child: Text('${index + 1}', textAlign: TextAlign.center),
                  ),
                  title: Text(titulos[index]),
                  selected: seleccion == index,
                  selectedTileColor: Theme.of(context)
                      .colorScheme
                      .primaryContainer,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  onTap: () => onSeleccion(index),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
