import 'package:flutter/material.dart';

import '../microapps/registro_nutricional/app_registro_nutricional.dart';

import '../nanoapps/membership/app_membership.dart';
import '../nanoapps/inicio/app_inicio.dart';
import '../microapps/seguimiento/app_seguimiento.dart';
import '../nanoapps/gastos/app_gastos.dart';
import '../nanoapps/balance/app_balance.dart';
import '../nanoapps/objetivos/app_objetivos.dart';
import '../nanoapps/progreso/app_progreso.dart';
import '../nanoapps/entrenadores_y_alumnos/app_entrenadores_y_alumnos.dart';
import '../nanoapps/configuracion/app_configuracion.dart';

const titulos = <String>[
  "Membership",
  "Inicio",
  "Consumos",
  "Gastos",
  "Balance",
  "Objetivos",
  "Progreso",
  "Entrenadores y alumnos",
  "Configuración",
  "Registro nutricional",
];
const pantallas = <Widget>[
  AppMembership(),
  AppInicio(),
  MicroappSeguimiento(),
  AppGastos(),
  AppBalance(),
  AppObjetivos(),
  AppProgreso(),
  AppEntrenadoresYAlumnos(),
  AppConfiguracion(),
  MicroappRegistroNutricional(),
];
