import 'package:flutter/material.dart';

import '../../microapps/seguimiento/app_seguimiento.dart';
import '../../ui/estilo_fenix.dart';

class AppInicio extends StatelessWidget {
  const AppInicio({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(24),
    children: [
      const CabeceraFenix(
        titulo: 'Inicio',
        descripcion: 'Resumen de tu estado actual',
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.restaurant, color: naranjaFenix, size: 36),
              const SizedBox(height: 16),
              const Text(
                'Tu registro nutricional',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Registra porciones y consulta calorías, proteínas, carbohidratos y grasas desde el historial de este equipo.',
              ),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => Scaffold(
                      appBar: AppBar(title: const Text('Consumos')),
                      body: const MicroappSeguimiento(),
                    ),
                  ),
                ),
                child: const Text('Ver mis consumos'),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 16),
      const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Los indicadores de peso, gasto energético y objetivos se conectarán a sus registros. No se muestran valores de ejemplo como si fueran tus datos.',
          ),
        ),
      ),
    ],
  );
}
