# Actualización · 31 octubre 2026

- Login, shell y menú adoptan el estilo aprobado de la versión anterior. La
  navegación entra en Inicio; salida local vuelve al login. Acceso Google/correo
  continúa pendiente en esta copia; botón explícito para trabajar localmente.
- Inicio ofrece acceso al historial; Consumos consulta y suma los snapshots de
  porciones en SQLite por día local. Selector/calendario, vacío, carga, reintento
  y descarte de respuestas obsoletas. Alta conserva editor/foto/voz existentes.
- Guardado de porción delegado en NanoFunción/NanoActividad. GET /porciones valida
  fecha y desfases de inicio/fin, incluidos días con cambio de hora. Sin migración.
- No se modificó la copia anterior de /home/rolo ni se inventaron perfiles, metas,
  pesos o membresías. Gastos, Balance, Objetivos, Progreso, Membresía, entrenadores
  y Configuración siguen pendientes de implementación en esta copia.
- Validación final en copia temporal: 12 pruebas Python y 6 pruebas Flutter
  aprobadas, flutter analyze sin incidencias y flutter build web correcto.
  Login a 320 px con texto 1.4x; historial a 320 px; HTTP real con reinicio,
  snapshots, límites diarios, cambio de hora, parámetros inválidos y CORS.
  Sin validación física Android/iOS, Firebase real, cámara, micrófono o Turso.
- Cuatro informes Word, README, arquitectura y guía nutricional actualizados.

# Cambios

## 2026-10-29 — Registro nutricional inicial

- Microapp integrada al final del menú y tres NanoApps: editor, foto y voz.
- SQLite versionado para fichas y porciones con snapshots e idempotencia.
- Sincronización Turso explícita con cola persistente y detección de conflictos.
- Preprocesado OpenCV, histograma HSV y candidatos revisables por color.
- Adaptador Gemini para audio/texto y JSON estructurado validado.
- Permisos de micrófono/cámara y configuración Android debug para servicio local.
- Validación: analizador Flutter y build web correctos; pruebas del backend y UI
  descritas en docs/registro_nutricional.md. Servicios externos probados con dobles
  de transporte; credenciales y dispositivos reales pendientes.

## 2026 10 14
Documentación inicial v0.1. Estado y propuestas diferenciados; capturas pendientes.
