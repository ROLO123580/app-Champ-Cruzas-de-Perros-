# Fénix Fitness

Versión 0.1 — 14 octubre 2026

## Alcance
Prioridad 1. Seguimiento diario de consumos, gastos y balance; entrenadores y alumnos.

## Estado
Código previo en el PC; no inspeccionado en esta sesión.

## Reglas de continuidad
- Leer este archivo y los cuatro informes de docs antes de modificar arquitectura.
- Inspeccionar código real; el informe no reemplaza el estado del repositorio.
- Mantener App → MicroApp → NanoApp → NanoFunción → NanoActividad.
- En la base actual las NanoApps se conectan al orquestador; agrupaciones MicroApp pendientes.
- Usar lib/main.dart y lib/app_fenix_fitness.dart como entrada y orquestador.
- NanoFunciones dentro de cada NanoApp; NanoActividades dentro de cada NanoFunción.
- No renombrar ni mover módulos sin actualizar imports, catálogo y documentación.
- Login es entrada; Membership pertenece al menú.
- No confundir navegación simulada con autenticación o servicios implementados.
- No borrar código existente para instalar un cascarón.

## Registro nutricional — 29 octubre 2026

Se incorpora MicroappRegistroNutricional al final del catálogo, con NanoApps de
editor, foto y voz, NanoFunciones por pantalla y NanoActividades puras.
SQLite se administra por servicio HTTP Python local; Turso sincroniza explícitamente
fichas y Gemini interpreta audio/texto desde el servicio. No se incorporan secretos
al cliente. OpenCV corre en el servicio; la UI web envía bytes, no File de dart:io.
El acceso existente sigue siendo visual. No se implementó backend multiusuario.
Rutas, límites, instalación y pruebas en [Registro nutricional](docs/registro_nutricional.md).
Los informes Word se amplían con esta entrega sin borrar su registro anterior.

## Pantallas
- Inicio
- Consumos
- Gastos
- Balance
- Objetivos
- Progreso
- Entrenadores y alumnos
- Configuración

## Backend
Firebase previsto para validación online; confirmar el estado del servicio y la autenticación existentes.
Visión alimentaria y API de IA posteriores; iniciar con registro manual y validación.

## Documentación
Guardar los cuatro Word en docs/; imágenes originales en docs/imagenes/.
Actualizar estado, decisiones, versión, rutas y pruebas al finalizar cambios.
Conservar un CHANGELOG.md con fecha, cambio, motivo y comprobación.

## Continuidad · 31 octubre 2026

Login y navegación recuperan el estilo de las capturas de la versión anterior.
Inicio abre tras el acceso local y ofrece entrada al historial. El acceso online
no está integrado en esta copia y la UI lo indica. Sin valores personales de demo.

MicroappSeguimiento agrupa Consumos, cuya NanoFunción ConsultarConsumos delega
en la NanoActividad leerHistorial. La confirmación usa registrarPorcion y
persistirPorcion. HTTP añade consulta diaria con desfase horario y totales desde
los snapshots originales de SQLite, sin migración de esquema. Se conservan los
índices del catálogo; el sidebar presenta el orden del diseño de referencia.
Más detalle y comandos sin conflicto con Champ en docs/registro_nutricional.md.
