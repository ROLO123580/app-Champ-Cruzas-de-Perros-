"""Servicio local para un perfil nutricional. No exponer a la red."""
import argparse
import base64
import json
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit, parse_qs

from nutricion.servicios import RegistroNutricional, Turso
from nutricion.vision import preprocesar_imagen_opencv


def binario(datos, clave):
    valor = datos.get(clave)
    if valor is None:
        return None
    if not isinstance(valor, str) or len(valor) > 11000000:
        raise ValueError('Archivo demasiado grande')
    contenido = base64.b64decode(valor, validate=True)
    if len(contenido) > 8000000:
        raise ValueError('Máximo 8 MB por archivo')
    return contenido


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # No registrar audio, fichas ni tokens.

    def responder(self, status, datos):
        contenido = json.dumps(datos, allow_nan=False).encode()
        self.send_response(status)
        origen = self.headers.get('Origin', '')
        if origen and self.permitido():
            self.send_header('Access-Control-Allow-Origin', origen)
            self.send_header('Vary', 'Origin')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(contenido)

    def permitido(self):
        locales = ('localhost', '127.0.0.1', '::1')
        host = urlsplit('http://' + self.headers.get('Host', '')).hostname
        origen = self.headers.get('Origin')
        return host in locales and (not origen or (urlsplit(origen).hostname in locales and urlsplit(origen).scheme == 'http'))

    def do_OPTIONS(self):
        self.responder(200 if self.permitido() else 403, {})

    def do_GET(self):
        if not self.permitido():
            return self.responder(403, {'error': 'Origen no autorizado'})
        ruta = urlsplit(self.path)
        if ruta.path == '/porciones':
            try:
                params = parse_qs(ruta.query, keep_blank_values=True)
                if not {'fecha', 'desfase'} <= set(params) or set(params) - {'fecha', 'desfase', 'desfase_fin'} or any(len(v) != 1 for v in params.values()):
                    raise ValueError('Indica fecha y desfase horario')
                resultado = self.server.registro.historial_diario(params['fecha'][0], int(params['desfase'][0]), int(params['desfase_fin'][0]) if 'desfase_fin' in params else None)
                return self.responder(200, resultado)
            except (ValueError, TypeError):
                return self.responder(400, {'error': 'Fecha o desfase horario inválido'})
            except Exception:
                return self.responder(503, {'error': 'No se pudo consultar el historial. Reintenta.'})
        if self.path == '/fichas':
            return self.responder(200, {'fichas': self.server.registro.listar()})
        if self.path == '/estado':
            return self.responder(200, {'turso': self.server.registro.remoto is not None,
                                       'gemini': bool(os.getenv('GEMINI_API_KEY') and os.getenv('GEMINI_MODEL'))})
        self.responder(404, {'error': 'Ruta desconocida'})

    def do_POST(self):
        if not self.permitido():
            return self.responder(403, {'error': 'Origen no autorizado'})
        try:
            self.connection.settimeout(20)
            longitud = int(self.headers.get('Content-Length', '0'))
            if not 0 < longitud <= 12000000 or self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('Se requiere JSON de hasta 12 MB')
            datos = json.loads(self.rfile.read(longitud))
            if not isinstance(datos, dict):
                raise ValueError('Se requiere un objeto JSON')
            registro = self.server.registro
            if self.path == '/fichas':
                result = registro.guardar_ficha_alimento(datos['ficha'], binario(datos, 'foto'), datos.get('roi'))
            elif self.path == '/voz':
                result = registro.procesar_voz_gemini(datos.get('texto'), binario(datos, 'audio'), datos.get('mime', 'audio/wav'))
            elif self.path == '/foto':
                foto = binario(datos, 'foto')
                if not foto:
                    raise ValueError('Foto requerida')
                result = preprocesar_imagen_opencv(foto, datos.get('roi'))
                hist = result['histograma']
                candidatos = []
                for ficha in registro.listar():
                    ref = ficha['histograma_color_opencv']
                    if ref and len(ref) == len(hist):
                        distancia = sum(abs(a - b) for a, b in zip(ref, hist)) / 2
                        candidatos.append({'ficha': ficha, 'distancia_color': distancia})
                result['candidatos'] = sorted(candidatos, key=lambda c: c['distancia_color'])[:3]
            elif self.path == '/porciones':
                result = registro.registrar(datos['ficha_id'], datos['gramos'], datos['version'], datos['solicitud_id'])
            elif self.path == '/sincronizar':
                result = registro.sincronizar()
            else:
                return self.responder(404, {'error': 'Ruta desconocida'})
            self.responder(200, result)
        except (ValueError, KeyError, TypeError) as exc:
            self.responder(400, {'error': str(exc)})
        except RuntimeError as exc:
            self.responder(503, {'error': str(exc)})
        except Exception:
            self.responder(503, {'error': 'No se pudo completar la operación. Los cambios locales confirmados se conservan.'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path.home() / '.local/share/RHIA/FenixFitness/nutricion')
    parser.add_argument('--port', type=int, default=8793)
    args = parser.parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    url, token = os.getenv('TURSO_DATABASE_URL'), os.getenv('TURSO_AUTH_TOKEN')
    if bool(url) != bool(token):
        parser.error('Configura URL y token Turso juntos')
    registro = RegistroNutricional(args.data_dir / 'nutricion.db',
                                  Turso(url, token) if url else None, os.getenv('FENIX_CATALOGO_ID'))
    server = HTTPServer(('127.0.0.1', args.port), Handler)
    server.registro = registro
    print(f'Nutrición: http://127.0.0.1:{args.port}; base {args.data_dir / "nutricion.db"}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        registro.db.close()


if __name__ == '__main__':
    main()
