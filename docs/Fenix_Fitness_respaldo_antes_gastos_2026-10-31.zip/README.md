# Fenix Fitness

Seguimiento de consumos, gastos y objetivos. El módulo **Registro nutricional**
permite editar fichas, confirmar porciones y usar foto o voz como asistencia.

Inicio y configuración: [Registro nutricional](docs/registro_nutricional.md).
El servicio Python mantiene SQLite local. Turso y Gemini son opcionales y
requieren configuración en el servicio; sus secretos no se incluyen en Flutter.

```bash
python3 tool/nutricion_api.py
flutter run -d chrome
```

Para OpenCV instalar primero las dependencias indicadas en la documentación.
El Login existente es visual; no acredita una sesión autenticada.

## Diseño y consumos · 31 octubre 2026

Se recupera el estilo anterior en Login, menú y Consumos. El historial diario
consulta porciones y totales persistidos; Inicio ofrece acceso directo.
Para ejecutar junto a Champ usa API 8796 y web 8797 con los comandos de
[Registro nutricional](docs/registro_nutricional.md). En esta copia el login
online sigue pendiente; utiliza **Abrir versión local** para trabajar en el equipo.
